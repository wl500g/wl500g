static char SNAPSHOT[] = "010824";
