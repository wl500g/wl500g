#include "netbsd.h"

#define netbsd1 /* we're really close to this */
