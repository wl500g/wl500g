#include "generic.h"

/* the bsd route symbol adds an 's' at the end to this symbol name */
#undef RTTABLES_SYMBOL
#define RTTABLES_SYMBOL "rt_tables"

/* BSD systems use a different method of looking up sockaddr_in values */
#define NEED_KLGETSA

/* ARP_Scan_Next needs a 4th ifIndex argument */
#define ARP_SCAN_FOUR_ARGUMENTS

#define UTMP_HAS_NO_TYPE
