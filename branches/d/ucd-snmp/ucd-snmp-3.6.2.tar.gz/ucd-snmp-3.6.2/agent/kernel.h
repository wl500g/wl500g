
#ifndef linux
extern void init_kmem (char *);
extern int klookup (unsigned long, char *, int);
#endif
