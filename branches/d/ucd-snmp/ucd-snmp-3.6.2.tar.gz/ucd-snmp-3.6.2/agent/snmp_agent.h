/* external definitions for functions in snmp_agent.c */
#ifndef SNMP_AGENT_H
#define SNMP_AGENT_H

/* config file parsing routines */
void snmp_agent_parse_config(char *, char *);

#endif
