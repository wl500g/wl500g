#ifndef SNMPTRAPD_HANDLERS_H
#define SNMPTRAPD_HANDLERS_H
char *snmptrapd_get_traphandler (oid *, int);
void snmptrapd_traphandle (char *, char *);

#endif /* SNMPTRAPD_HANDLERS_H */
